const Discord = require('discord.js');

exports.run = async (client, message, args) => {

var list = [
  'https://cdn.discordapp.com/attachments/741247821285687367/781600530391629884/unnamed_3.gif',
  'https://cdn.discordapp.com/attachments/741247821285687367/781600530715377664/unnamed_2.gif',
 'https://cdn.discordapp.com/attachments/741247821285687367/781600531512164412/unnamed.gif',
  'https://cdn.discordapp.com/attachments/741247821285687367/781600531230883871/unnamed_1.gif'
];

var rand = list[Math.floor(Math.random() * list.length)];
let user = message.mentions.users.first() || client.users.cache.get(args[0]);
if (!user) {
return message.reply('lembre-se de mencionar um usuário válido para beijar!');
}
/*
message.channel.send(`${message.author.username} **Beijou** ${user.username}! :heart:`, {files: [rand]});
*/
let avatar = message.author.displayAvatarURL({format: 'png'});
  const embed = new Discord.MessageEmbed()
        .setTitle('COMANDO DE BEIJAR')
        .setColor('RANDOM')
        .setDescription(`${message.author} acaba de beijar ${user}`)
        .setImage(rand)
        .setTimestamp()
        .setThumbnail(avatar)
        .setFooter('Comando de diversão Los Santos Roleplay Xbox ®')
        .setAuthor(message.author.tag, avatar);
  await message.channel.send(embed);
}