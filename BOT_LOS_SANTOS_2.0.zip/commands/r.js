const Discord = require('discord.js');

module.exports.run = async (client, message, args) => {
	
  let say = args.join(' ');
   if(!say) return message.reply("saymessage")
  message.delete();
  let embed = new Discord.MessageEmbed()
    .setDescription(say)
    .setColor("RANDOM")
  message.channel.send(embed);
};