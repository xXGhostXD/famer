
const Discord = require(`discord.js`);
const prefix = ("!")


exports.run = async (client, message, args) => {

    let guild = await client.guilds.cache.get("734856846652735559");
    
    const embe = new Discord.MessageEmbed()
        .setTitle('SISTEMA DE WHITELIST LOS SANTOS ROLEPLAY')
        .setDescription('Olá seja bem-vindo(a) ao Los Santos Roleplay,para você continuar sua whitelist,olhe o privado e veja a mensagem que nosso bot,de whitelist lhe enviou.')
        .setColor('#ffff00')
        .setThumbnail('https://cdn.discordapp.com/attachments/703407139720265779/780951696327049226/1606250223925-1.jpg')
        .setTimestamp()
        .setFooter('🏙️ Los Santos Roleplay Xbox One | ©Todos os direitos reservados.')

    await message.author.createDM()
    message.delete()
    message.channel.send(embe)
    const embed = new Discord.MessageEmbed()
        .setAuthor('WHITELIST LOS SANTOS ROLEPLAY', client.user.avatarURL())
        .setDescription('➡️Olá,vamos fazer sua WHITELIST, explique ela de forma clara e obvia. \n \n  📌 Para começar Fazer sua WHITELIST digite \`iniciar`\, não será tolerado brincadeiras com este comando, caso acontecer será punido sem aviso prévio,caso queira cancelar a whitelist,digite ``cancelar``.')
        .setColor('#ffff00')
        .setThumbnail('https://cdn.discordapp.com/attachments/703407139720265779/780951696327049226/1606250223925-1.jpg')
        .setTimestamp()
        .setFooter('🏙️Los Santos Roleplay Xbox One | ©Todos os direitos reservados.')
    message.author.send(embed)

    var main = message.author.dmChannel.createMessageCollector(a => a.author.id == message.author.id, {
        time: 100000 * 50,
        max: 1
    })

    main.on('collect', a => {

        const pergun1 = new Discord.MessageEmbed()
            .setColor("#ffff00")
            .setDescription(`**➡️ - QUAL SEU NOME NO DISCORD?** `) /*Pergunta 1*/
            .setThumbnail('https://cdn.discordapp.com/attachments/703407139720265779/780951696327049226/1606250223925-1.jpg')

        if (a.content.toLowerCase() === "cancelar") return message.author.send('Whitelist cancelada.');
        if (a.content.toLowerCase() === "iniciar") message.author.send(pergun1)

        var prg2 = message.author.dmChannel.createMessageCollector(b => b.author.id == message.author.id, {
            time: 100000 * 50,
            max: 1
        })

        prg2.on('collect', b => {
            if (b.content.toLowerCase() === "cancelar") return message.author.send('Whitelist cancelada');
            let n1 = b.content
            const pergun2 = new Discord.MessageEmbed()
                .setColor("#ffff00")
                .setDescription(`**➡️ - QUAL SUA GAMERTAG DO XBOX LIVE?**`) /*Pergunta 2*/
                .setThumbnail('https://cdn.discordapp.com/attachments/703407139720265779/780951696327049226/1606250223925-1.jpg')
            message.author.send(pergun2)

            var prg28 = message.author.dmChannel.createMessageCollector(f => f.author.id == message.author.id, {
                time: 100000 * 50,
                max: 1
            })

            prg28.on('collect', f => {
                if (b.content.toLowerCase() === "cancelar") return message.author.send('Whitelist cancelada');
                let n3 = f.content
                const pergun3 = new Discord.MessageEmbed()
                    .setColor("#ffff00")
                    .setDescription(`**➡️ - O QUE É TER AMOR A VIDA?**`) /*Pergunta 3*/
                    .setThumbnail('https://cdn.discordapp.com/attachments/703407139720265779/780951696327049226/1606250223925-1.jpg')
                message.author.send(pergun3)

                var prg27 = message.author.dmChannel.createMessageCollector(c => c.author.id == message.author.id, {
                    time: 100000 * 50,
                    max: 1
                })

                prg27.on('collect', b => {
                    if (b.content.toLowerCase() === "cancelar") return message.author.send('Whitelist cancelada');
                    let n4 = b.content
                    const pergun2 = new Discord.MessageEmbed()
                        .setColor("#ffff00")
                        .setDescription(`**➡️ - CRIE UMA HISTORIA PARA O SEU PERSONAGEM:**`) /*Pergunta 4*/
                        .setThumbnail('https://cdn.discordapp.com/attachments/703407139720265779/780951696327049226/1606250223925-1.jpg')
                    message.author.send(pergun2)
        
                    var prg28 = message.author.dmChannel.createMessageCollector(f => f.author.id == message.author.id, {
                        time: 100000 * 50,
                        max: 1
                    })
        
                    prg28.on('collect', f => {
                        if (b.content.toLowerCase() === "cancelar") return message.author.send('Whitelist cancelada');
                        let n5 = f.content
                        const pergun3 = new Discord.MessageEmbed()
                            .setColor("#ffff00")
                            .setDescription(`**➡️ - O QUE É RDM,METAGAMING,POWERGAMING,VDM E COMBAT LOG?**`) /*Pergunta 5*/
                            .setThumbnail('https://cdn.discordapp.com/attachments/703407139720265779/780951696327049226/1606250223925-1.jpg')
                        message.author.send(pergun3)
        
                        var fim = message.author.dmChannel.createMessageCollector(c => c.author.id == message.author.id, {
                            time: 100000 * 50,
                            max: 1
                        })                    

                fim.on('collect', c => {
                    let n2 = c.content
                    const pergun3 = new Discord.MessageEmbed()
                        .setColor("#ffff00")
                        .setDescription(`**Sua WHITELIST foi enviada com sucesso aguarde algum staff analisar se você for aprovado,aparecerá no chat: <#734861416644739152>**`)
                        .setThumbnail('https://cdn.discordapp.com/attachments/703407139720265779/780951696327049226/1606250223925-1.jpg')
                    message.author.send(pergun3)

                    const avaliacao = new Discord.MessageEmbed()
                        .setTitle("**WHITELIST NOVA**")
                        .setColor("#ffff00")
                        .setDescription(`**NOME NO DISCORD:**\`\`\`${n1}\`\`\` \n**GAMERTAG XBOX LIVE:** \`\`\`${n3}\`\`\` \n**O QUE É TER AMOR A VIDA:** \`\`\`${n4}\`\`\` \n**O QUE É RDM,METAGAMING,POWERGAMING,VDM E COMBAT LOG:**\`\`\`${n2}\`\`\` \n**HISTORIA DO PERSONAGEM:**\`\`\`${n5}\`\`\``)
                        .setThumbnail("https://cdn.discordapp.com/attachments/703407139720265779/780951696327049226/1606250223925-1.jpg")
                        .setFooter('Los Santos Roleplay Xbox One ® | © Todos os direitos reservados.')
                        client.channels.cache.get('734861431618535466').send("Nova Whitelist Recebida<@&734861211383889941>")
                    client.channels.cache.get('780499998344347658').send(avaliacao).then(async msg => {
                    });
                });
            });
        });
    });
});
});
};
exports.help = {
    name: "white"
}