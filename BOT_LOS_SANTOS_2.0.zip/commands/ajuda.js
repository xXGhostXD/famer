const Discord = require('discord.js');

module.exports.run = async (client, message, args) => {
	
  const embed = new Discord.MessageEmbed()
    .setTitle('<a:alerta:781559915927044105>COMANDO DE AJUDA<a:alerta:781559915927044105>')
    .setDescription('**<a:seta:781559950357954570>Olá veja a lista de comandos abaixo:\n__!bot-status___ - Veja o status do bot.\n__!avatar__ - Veja o seu avatar ou de outra pessoa,colocando !avatar + __o nome da pessoa.__\n__/anonimo__ - Envie uma mensagem anonimamente.\n__!kiss__ - Beije uma pessoa,colocando !kiss + __o nome da pessoa__.\n__!purge__ - Exclua mensagens utilizando este comando,exemplo: !purge 10,irá apagar 10 mensagens.\n__!ping__ - Veja o ping do bot.\n__!r__ - Envie uma mensagem em embed utlizando este comando,exemplo: !r oi.\n__!b__ - Envie uma mensagem com o bot utilizando este comando,exemplo: !b Ola.\n__!coinflip__ - Jogue cara ou coroa,utilizando este comando,exemplo: !coinflip cara.\nO SISTEMA DE WHITELIST É EXCLUSIVO PARA DOADORES,SE O SEU SERVIDOR JA POSSUI O SISTEMA IGNORE ESTA MENSAGEM.**')
    .setColor("YELLOW")
    .setThumbnail("https://cdn.discordapp.com/attachments/670367455184420894/781551361438908467/20201126_130450.gif")
    .setFooter("Developed By xXGhøstXD#3924,https://discord.gg/Yh4574dudz Fire Lab Store ®")
  message.channel.send(embed);
};